# Toggling the Builder
formBuilder and formRender ship as separate plugins because in most cases formBuilder will be used for the admin part of a website and the form it generates will be displayed in another area. In some cases the functionality of both needs to be combined, below you'll find a basic example of how to do that.

## Demo 
<p data-height="535" data-theme-id="22927" data-slug-hash="obyeya" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
