[
	{
		"type": "autocomplete",
		"required": true,
		"label": "Custom Autocomplete",
		"className": "form-control",
		"name": "autocomplete-1522390847087",
		"values": [
			{
				"label": "SQL",
				"value": "1"
			},
			{
				"label": "C#",
				"value": "2"
			},
			{
				"label": "JavaScript",
				"value": "3"
			},
			{
				"label": "Java",
				"value": "4"
			},
			{
				"label": "Python",
				"value": "5"
			},
			{
				"label": "C++",
				"value": "6"
			},
			{
				"label": "PHP",
				"value": "7"
			},
			{
				"label": "Swift",
				"value": "8"
			},
			{
				"label": "Ruby",
				"value": "9"
			}
		]
	}
]