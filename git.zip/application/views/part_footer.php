<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js" type="text/javascript"></script>
 <script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js" type="text/javascript"></script>
 <script src="//cdnjs.cloudflare.com/ajax/libs/modernizr/2.6.2/modernizr.min.js" type="text/javascript"></script>
 <script src="assets/javascripts/application-985b892b.js" type="text/javascript"></script>
 <script src="<?php echo site_url('assets/angular.min.js'); ?>" ></script>
 
 
  </body>
</html>