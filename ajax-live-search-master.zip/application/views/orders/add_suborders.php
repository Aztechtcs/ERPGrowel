<div class="col-md-6">
							<form role="form" method="post">
                                                            
                                                            <input type="text" placeholder="Order Name" name="order_name"> 
                                                            
								<div class="form-group">
									<label>order Id</label>
                                                                        <table>
                                                                            <th>Style Code</th>
                                                                             <th>Quentity</th>
                                                                            <tr>
                                                                                <td><input type="text" name="style[]" placeholder="Order Style 1"></td>
                                                                                <td><input type="number" name="q[]" placeholder="Order Quentity 1"></td>
                                                                            </tr>
                                                                             <tr>
                                                                                <td><input type="text" name="style[]" placeholder="Order Style 2"></td>
                                                                                <td><input type="number" name="q[]" placeholder="Order Quentity 2" ></td>
                                                                            </tr>
                                                                             <tr>
                                                                                <td><input type="text" name="style[]" placeholder="Order Style 3"></td>
                                                                                <td><input type="number" placeholder="Order Quentity 3" name="q[]" ></td>
                                                                            </tr>
                                                                             <tr>
                                                                                <td><input type="text" name="style[]" placeholder="Order Style 4"></td>
                                                                                <td><input type="number" placeholder="Order Quentity 4" name="q[]" ></td>
                                                                            </tr>
                                                                            
                                                                        </table>
                                                                         
                                                                      <?php /*  <input class="form-control" placeholder="Order Style 2">
                                                                        <input class="form-control" placeholder="Order Style 3">
                                                                        <input class="form-control" placeholder="Order Style 4"> */ ?>
								</div>
                                                            <button type="button" id="add_Sorder" class="btn btn-lg btn-primary">ADD Order</button>
                                                            
                                                            
								<!--<div class="form-group">
									<label>Password</label>
									<input type="password" class="form-control">
								</div>
								<div class="form-group checkbox">
									<label>
										<input type="checkbox">Remember me
									</label>
								</div>
								<div class="form-group">
									<label>File input</label>
									<input type="file">
									<p class="help-block">Example block-level help text here.</p>
								</div>
								<div class="form-group">
									<label>Text area</label>
									<textarea class="form-control" rows="3"></textarea>
								</div>
								<label>Validation</label>
								<div class="form-group has-success">
									<input class="form-control" placeholder="Success">
								</div>
								<div class="form-group has-warning">
									<input class="form-control" placeholder="Warning">
								</div>
								<div class="form-group has-error">
									<input class="form-control" placeholder="Error">
								</div> -->
</div>
