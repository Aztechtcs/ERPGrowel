<table>
<tr>
<form id="sd" >
<td><input type="button" id="addword" value="add work"></td>
<td><input type="text" id="word2" placeholder="Your Working Discription here" required> </td>
</form>
</tr>
</table>

<div id="tbl"></div>
<div id="success"></div>
<script src="<?php echo site_url(); ?>/js/jquery-3.3.1.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script>
    
    
    

</script>