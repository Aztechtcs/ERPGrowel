<html>
    <head>
        <title>All Work page</title>
    </head>
    <body>
        <?php 
        var_dump($data);
        ?>
    </body>
    
    
</html>