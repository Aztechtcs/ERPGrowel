<?php /*[{"type": "text","required": true,"label": "Supplier Name","placeholder": "Supplier Name","name": "name","subtype": "text","className": "red form-control"},{"type": "text","required": true,"label": "Email","placeholder": "Email","name": "email","subtype": "text","className": "red form-control"},{"type": "number","required": true,"label": "Number","placeholder": "Number","className": "form-control","name": "number"},{"type": "submit","label": "Click for add supplier","subtype": "button","className": "btn btn-primary","name": "button-1522236046994","style": "primary","value":'Click for add supplier'}]
 * */ ?>

[
	{
		"type": "text",
		"required": true,
		"label": "Supplier Name",
		"description": "Supplier Name",
		"placeholder": "Supplier Name",
		"name": "name",
		"subtype": "text",
		"className": "red form-control"
	},
	{
		"type": "button",
		"subtype": "submit",
		"label": "Supplier",
		"className": "btn btn-default",
		"name": "name",
		"style": "default"
	}
]